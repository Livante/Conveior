package keyboard;

import java.util.Scanner;

public class Keyboard {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Mesaj: ");
		String s = scanner.nextLine();
		System.out.println(s);
		scanner.close();
	}

	private Scanner scanner = new Scanner(System.in);

	public String getString(String message) {
		System.out.print(message);
		return scanner.nextLine();
	}
}
