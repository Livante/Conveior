package conveior.application.backtracking;

import java.util.ArrayList;
import java.util.List;

public class Path {

	private List<List<Integer>> solutions = new ArrayList<>();
	private List<Integer> solution = new ArrayList<>();

	public void init(int current, int stop, int article, List<Route> route, List<ArtRoute> art) {
		solution.clear();
		solutions.clear();
		List<ArtRoute> restrictions = new ArrayList<ArtRoute>();
		for (ArtRoute elem : art) {
			if (elem.getIdArticol() == article) {
				restrictions.add(elem);
			}
		}
		findPaths(current, stop, article, route, restrictions);
		showRezult();
	}

	public void findPaths(int current, int stop, int article, List<Route> route, List<ArtRoute> art) {

		if (solution.contains(current)) {
			return;
		}

		if (stop == current) {
			solution.add(stop);
			if (isValid(solution, art, article)) {
				List<Integer> clone = new ArrayList<>(solution);
				solutions.add(clone);
				solution.remove(solution.size() - 1);
				return;
			} else {
				solution.remove(solution.size() - 1);
			}
		}

		solution.add(current);
		for (Route rou : route) {
			if (rou.getIdNodCurrent() == current) {
				findPaths(rou.getIdNodnext(), stop, article, route, art);
			}
		}
		solution.remove(solution.size() - 1);

	}

	private boolean isValid(List<Integer> solution2, List<ArtRoute> art, int article) {
		boolean valid = false;
		for (ArtRoute check : art) {
			if (check.getIdArticol() == article) {
				if (solution.contains(check.getIdCurrentNode()) && solution.contains(check.getIdNextNode())) {
					valid = true;
				}
			}
		}
		return valid;
	}

	private void showRezult() {
		if (solutions.size() == 0) {
			System.out.println("There is no possible way!");
		}
		for (List<Integer> rez : solutions) {
			System.out.println(rez);
		}

	}
}
