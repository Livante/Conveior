package conveior.application.backtracking;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class Reader {
	public ArrayList<Input> readInput(CInputs reader, StringBuffer strLine, String filename) {
		try {
			List<Input> aux = new ArrayList<Input>();
			reader.OpenFile(filename);
			while (reader.ReadLine(strLine)) {
				String container = strLine.substring(0, strLine.indexOf(","));
				String articol = strLine.substring(strLine.indexOf(",") + 1);
				int idContainer = Integer.parseInt(container);
				int idArticol = Integer.parseInt(articol);
				Input in = new Input(idContainer, idArticol);
				aux.add(in);
			}
			return (ArrayList<Input>) aux;

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<Route> readRoute(CInputs reader, StringBuffer strLine, String filename) {
		try {
			List<Route> aux = new ArrayList<Route>();
			reader.OpenFile(filename);
			while (reader.ReadLine(strLine)) {
				String current = strLine.substring(0, strLine.indexOf(","));
				String next = strLine.substring(strLine.indexOf(",") + 1);
				int currentNode = Integer.parseInt(current);
				int nextNode = Integer.parseInt(next);
				Route route = new Route(currentNode, nextNode);
				aux.add(route);
			}
			return (ArrayList<Route>) aux;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<ArtRoute> readArtRoute(CInputs reader, StringBuffer strLine, String filename) {
		try {
			List<ArtRoute> aux = new ArrayList<ArtRoute>();

			reader.OpenFile(filename);
			while (reader.ReadLine(strLine)) {
				String articol = strLine.substring(0, strLine.indexOf(","));
				String current = strLine.substring(strLine.indexOf(",") + 1, strLine.lastIndexOf(","));
				String next = strLine.substring(strLine.lastIndexOf(",") + 1);
				int idArticol = Integer.parseInt(articol);
				int idCurrent = Integer.parseInt(current);
				int idNext = Integer.parseInt(next);
				ArtRoute art = new ArtRoute(idArticol, idCurrent, idNext);
				aux.add(art);
			}
			return (ArrayList<ArtRoute>) aux;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}
