package conveior.application.backtracking;

import java.util.ArrayList;
import java.util.List;

import keyboard.Keyboard;

public class Application {
	public static final String INPUT_FILE = "inputs.txt";
	public static final String ROUTE_FILE = "routes.txt";
	public static final String ART_ROUTE_FILE = "art_routes.txt";

	public final static int START = 0;
	public final static int STOP = 100;

	public List<Input> data = new ArrayList<Input>();
	public List<Route> route = new ArrayList<Route>();
	public List<ArtRoute> artRoute = new ArrayList<ArtRoute>();

	public static void main(String[] args) {
		Application app = new Application();
		app.run();
	}

	public void run() {
		CInputs reader = new CInputs();
		StringBuffer strLine = new StringBuffer();
		Reader read = new Reader();
		Path results = new Path();
		Keyboard keyboard = new Keyboard();

		data = read.readInput(reader, strLine, INPUT_FILE);
		route = read.readRoute(reader, strLine, ROUTE_FILE);
		artRoute = read.readArtRoute(reader, strLine, ART_ROUTE_FILE);

		while (true) {
			String key = keyboard.getString("Insert the container: ");
			if (key.toUpperCase().equals("X")) {
				break;
			}

			try {
				int container = Integer.parseInt(key);

				boolean valid = false;
				for (Input d : data) {
					if (d.getIdContainer() == container) {
						System.out.println("The result for the container " + key + " is:");
						for (Input article : data) {
							if (article.getIdContainer() == container) {
								results.init(START, STOP, article.getIdArticol(), route, artRoute);
							}
						}
						valid = true;
						break;
					}
				}
				if (!valid) {
					System.out.println("The container does not exist!");
				}

			} catch (Exception e) {
				System.out.println("Wrong input");
			}
		}
	}
}
