package conveior.application.backtracking;

public class ArtRoute {

	private int idArticol;
	private int idCurrentNode;
	private int idNextNode;

	public ArtRoute(int idArticol, int idCurrentNode, int idNextNode) {
		super();
		this.idArticol = idArticol;
		this.idCurrentNode = idCurrentNode;
		this.idNextNode = idNextNode;
	}

	@Override
	public String toString() {
		return "ArtRoute [idArticol=" + idArticol + ", idCurrentNode=" + idCurrentNode + ", idNextNode=" + idNextNode
				+ "]";
	}

	public int getIdArticol() {
		return idArticol;
	}

	public int getIdCurrentNode() {
		return idCurrentNode;
	}

	public int getIdNextNode() {
		return idNextNode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idArticol;
		result = prime * result + idCurrentNode;
		result = prime * result + idNextNode;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ArtRoute other = (ArtRoute) obj;
		if (idArticol != other.idArticol)
			return false;
		if (idCurrentNode != other.idCurrentNode)
			return false;
		if (idNextNode != other.idNextNode)
			return false;
		return true;
	}

}
