package conveior.application.backtracking;

public class Route {

	private int idNodCurrent;
	private int idNodnext;

	public Route(int idNodCurrent, int idNodnext) {
		this.idNodCurrent = idNodCurrent;
		this.idNodnext = idNodnext;
	}

	@Override
	public String toString() {
		return "Route [idNodCurrent=" + idNodCurrent + ", idNodnext=" + idNodnext + "]";
	}

	public int getIdNodCurrent() {
		return idNodCurrent;
	}

	public int getIdNodnext() {
		return idNodnext;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idNodCurrent;
		result = prime * result + idNodnext;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Route other = (Route) obj;
		if (idNodCurrent != other.idNodCurrent)
			return false;
		if (idNodnext != other.idNodnext)
			return false;
		return true;
	}

}
