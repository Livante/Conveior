package conveior.application.backtracking;

import java.io.FileNotFoundException;

public interface RbtDataFile {

	public void OpenFile(String strFileName) throws FileNotFoundException;

	public boolean ReadLine(StringBuffer strLine);
}