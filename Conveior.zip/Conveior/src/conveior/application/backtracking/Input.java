package conveior.application.backtracking;

public class Input {

	private int idContainer;
	private int idArticol;

	public Input(int idContainer, int idArticol) {
		this.idContainer = idContainer;
		this.idArticol = idArticol;
	}

	@Override
	public String toString() {
		return "Input [idContainer=" + idContainer + ", idArticol=" + idArticol + "]";
	}

	public Input() {
	}

	public int getIdContainer() {
		return idContainer;
	}

	public int getIdArticol() {
		return idArticol;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idArticol;
		result = prime * result + idContainer;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Input other = (Input) obj;
		if (idArticol != other.idArticol)
			return false;
		if (idContainer != other.idContainer)
			return false;
		return true;
	}

}
