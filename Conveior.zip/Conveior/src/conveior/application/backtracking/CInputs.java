package conveior.application.backtracking;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class CInputs extends Object implements RbtDataFile {

	private String m_strFileName;
	private FileInputStream m_streamIn;
	private byte m_buffer[];

	public CInputs() {
		m_strFileName = null;
		m_streamIn = null;
		m_buffer = new byte[100];
	}

	@Override
	public void OpenFile(String strFileName) throws FileNotFoundException {
		m_strFileName = strFileName;
		m_streamIn = new FileInputStream(m_strFileName);
	}

	@Override
	public boolean ReadLine(StringBuffer strLine) {
		if (null != m_streamIn) {
			byte ch = 0;
			while (-1 != ch) {
				int i = 0;

				try {
					ch = (byte) m_streamIn.read();
					while (ch != 10 && ch != -1) {
						m_buffer[i++] = ch;
						ch = (byte) m_streamIn.read();

					}
					if (i > 0) { 
						m_buffer[--i] = 0;
						String tmpString = new String(m_buffer, 0, i);
						strLine.replace(0, strLine.length(), tmpString);
						return true;
					} else {
					}
				} catch (IOException e) {
				}
			}
		}

		return false;
	}

}